package com.amor.member.model;

import java.util.*;

public interface MemberDAO {
	
	public MemberDTO memberLogin(String id);
    public MemberDTO findUserId(String member_name, String member_email);
}
