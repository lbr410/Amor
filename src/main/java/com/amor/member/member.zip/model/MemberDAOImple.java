package com.amor.member.model;

import org.mybatis.spring.SqlSessionTemplate;
import java.util.*;

public class MemberDAOImple implements MemberDAO {
	
	private SqlSessionTemplate sqlmap;

	public MemberDAOImple(SqlSessionTemplate sqlmap) {
		super();
		this.sqlmap = sqlmap;
	}

	@Override	
	public MemberDTO memberLogin(String id) {
		MemberDTO result=sqlmap.selectOne("memberLogin", id);
		System.out.println(result);
		return result;
	}
	
	@Override
	public String findUserId(String member_name, String member_email) {
	    Map<String, String> parameters = new HashMap<>();
	    parameters.put("member_name", member_name);
	    parameters.put("member_email", member_email);
	    String result = sqlmap.selectOne("userIdFind", parameters);
	    System.out.println(result);
	    return result;
	}
	
}
