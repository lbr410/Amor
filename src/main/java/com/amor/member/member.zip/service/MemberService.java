package com.amor.member.service;

import java.util.*;

import com.amor.member.model.*;

public interface MemberService {
	
	public String memberLogin (MemberDTO dto,String saveid);
    public HashMap<String, Object> findUserId(String member_name, String member_email);

}
